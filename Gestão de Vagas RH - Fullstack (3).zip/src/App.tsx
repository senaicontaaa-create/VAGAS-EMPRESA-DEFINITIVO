
import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Layout from './components/Layout'
import ListaVagas from './pages/ListaVagas'
import CriarVaga from './pages/CriarVaga'
import EditarVaga from './pages/EditarVaga'
import DetalhesVaga from './pages/DetalhesVaga'

function App() {
  return (
    <>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#363636',
            color: '#fff',
          },
          success: {
            style: {
              background: '#10b981',
            },
          },
          error: {
            style: {
              background: '#ef4444',
            },
          },
        }}
      />
      
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<ListaVagas />} />
            <Route path="/criar" element={<CriarVaga />} />
            <Route path="/editar/:id" element={<EditarVaga />} />
            <Route path="/detalhes/:id" element={<DetalhesVaga />} />
          </Routes>
        </Layout>
      </Router>
    </>
  )
}

export default App
