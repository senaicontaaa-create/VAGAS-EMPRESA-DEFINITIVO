
import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useVagas, type Vaga } from '../hooks/useVagas'
import {ArrowLeft, Save} from 'lucide-react'

const EditarVaga: React.FC = () => {
  const navigate = useNavigate()
  const { id } = useParams<{ id: string }>()
  const { atualizarVaga, obterVaga } = useVagas()
  const [vaga, setVaga] = useState<Vaga | null>(null)
  const [loading, setLoading] = useState(false)
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    const carregarVaga = async () => {
      if (!id) return
      
      const vagaEncontrada = await obterVaga(id)
      setVaga(vagaEncontrada)
      setCarregando(false)
    }

    carregarVaga()
  }, [id, obterVaga])

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!id) return
    
    setLoading(true)
    const formData = new FormData(event.currentTarget)
    
    try {
      await atualizarVaga(id, {
        descricaoCargo: formData.get('descricaoCargo') as string,
        requisitosObrigatorios: formData.get('requisitosObrigatorios') as string,
        requisitosDesejaveis: formData.get('requisitosDesejaveis') as string || undefined,
        remuneracaoMensal: Number(formData.get('remuneracaoMensal')),
        beneficios: formData.get('beneficios') as string || undefined,
        localTrabalho: formData.get('localTrabalho') as string,
        status: formData.get('status') as 'aberta' | 'preenchida' | 'cancelada',
        departamento: formData.get('departamento') as string || undefined,
        tipoContrato: formData.get('tipoContrato') as string || undefined,
        cargaHoraria: formData.get('cargaHoraria') as string || undefined
      })
      
      navigate('/')
    } catch (error) {
      // Erro já tratado no hook
    } finally {
      setLoading(false)
    }
  }

  if (carregando) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!vaga) {
    return (
      <div className="card text-center py-12">
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Vaga não encontrada
        </h3>
        <p className="text-gray-600 mb-6">
          A vaga solicitada não foi encontrada.
        </p>
        <button onClick={() => navigate('/')} className="btn-primary">
          Voltar à lista
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={() => navigate('/')}
          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Editar Vaga</h1>
          <p className="text-gray-600 mt-1">
            Atualize as informações da vaga
          </p>
        </div>
      </div>

      {/* Formulário */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            Informações Básicas
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descrição do Cargo *
              </label>
              <input
                type="text"
                name="descricaoCargo"
                required
                defaultValue={vaga.descricaoCargo}
                className="input-field"
                placeholder="Ex: Desenvolvedor Full Stack Sênior"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Remuneração Mensal (R$) *
              </label>
              <input
                type="number"
                name="remuneracaoMensal"
                min="0"
                step="0.01"
                required
                defaultValue={vaga.remuneracaoMensal}
                className="input-field"
                placeholder="5000.00"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Local de Trabalho *
              </label>
              <input
                type="text"
                name="localTrabalho"
                required
                defaultValue={vaga.localTrabalho}
                className="input-field"
                placeholder="São Paulo - SP (Híbrido)"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status *
              </label>
              <select name="status" required defaultValue={vaga.status} className="input-field">
                <option value="aberta">Aberta</option>
                <option value="preenchida">Preenchida</option>
                <option value="cancelada">Cancelada</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Departamento
              </label>
              <input
                type="text"
                name="departamento"
                defaultValue={vaga.departamento || ''}
                className="input-field"
                placeholder="Tecnologia"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tipo de Contrato
              </label>
              <select name="tipoContrato" defaultValue={vaga.tipoContrato || ''} className="input-field">
                <option value="">Selecione...</option>
                <option value="CLT">CLT</option>
                <option value="PJ">PJ</option>
                <option value="Estágio">Estágio</option>
                <option value="Temporário">Temporário</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Carga Horária
              </label>
              <input
                type="text"
                name="cargaHoraria"
                defaultValue={vaga.cargaHoraria || ''}
                className="input-field"
                placeholder="40 horas semanais"
              />
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            Requisitos e Benefícios
          </h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Requisitos Obrigatórios *
              </label>
              <textarea
                name="requisitosObrigatorios"
                required
                rows={4}
                defaultValue={vaga.requisitosObrigatorios}
                className="input-field"
                placeholder="Descreva os requisitos obrigatórios para a vaga..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Requisitos Desejáveis
              </label>
              <textarea
                name="requisitosDesejaveis"
                rows={3}
                defaultValue={vaga.requisitosDesejaveis || ''}
                className="input-field"
                placeholder="Descreva os requisitos desejáveis para a vaga..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Benefícios
              </label>
              <textarea
                name="beneficios"
                rows={3}
                defaultValue={vaga.beneficios || ''}
                className="input-field"
                placeholder="Descreva os benefícios oferecidos..."
              />
            </div>
          </div>
        </div>

        {/* Botões de Ação */}
        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="btn-secondary"
          >
            Cancelar
          </button>
          
          <button
            type="submit"
            disabled={loading}
            className="btn-primary flex items-center space-x-2"
          >
            <Save className="h-5 w-5" />
            <span>{loading ? 'Salvando...' : 'Salvar Alterações'}</span>
          </button>
        </div>
      </form>
    </div>
  )
}

export default EditarVaga
