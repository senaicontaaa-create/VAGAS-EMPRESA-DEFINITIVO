
import React, { useState, useEffect } from 'react'
import { useNavigate, useParams, Link } from 'react-router-dom'
import { useVagas, type Vaga } from '../hooks/useVagas'
import {ArrowLeft, Edit, Trash2, MapPin, DollarSign, Calendar, Building, Clock, FileText, Award, User, Briefcase} from 'lucide-react'

const DetalhesVaga: React.FC = () => {
  const navigate = useNavigate()
  const { id } = useParams<{ id: string }>()
  const { obterVaga, excluirVaga } = useVagas()
  const [vaga, setVaga] = useState<Vaga | null>(null)
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    const carregarVaga = async () => {
      if (!id) return
      
      const vagaEncontrada = await obterVaga(id)
      setVaga(vagaEncontrada)
      setCarregando(false)
    }

    carregarVaga()
  }, [id, obterVaga])

  const handleExcluir = async () => {
    if (!vaga || !id) return
    
    if (window.confirm(`Tem certeza que deseja excluir a vaga "${vaga.descricaoCargo}"?`)) {
      await excluirVaga(id)
      navigate('/')
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'aberta':
        return 'bg-green-100 text-green-800'
      case 'preenchida':
        return 'bg-blue-100 text-blue-800'
      case 'cancelada':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'aberta':
        return 'Aberta'
      case 'preenchida':
        return 'Preenchida'
      case 'cancelada':
        return 'Cancelada'
      default:
        return status
    }
  }

  if (carregando) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!vaga) {
    return (
      <div className="card text-center py-12">
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Vaga não encontrada
        </h3>
        <p className="text-gray-600 mb-6">
          A vaga solicitada não foi encontrada.
        </p>
        <button onClick={() => navigate('/')} className="btn-primary">
          Voltar à lista
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/')}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {vaga.descricaoCargo}
            </h1>
            <p className="text-gray-600 mt-1">
              Detalhes completos da vaga
            </p>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <Link
            to={`/editar/${vaga._id}`}
            className="btn-secondary flex items-center space-x-2"
          >
            <Edit className="h-5 w-5" />
            <span>Editar</span>
          </Link>
          
          <button
            onClick={handleExcluir}
            className="btn-danger flex items-center space-x-2"
          >
            <Trash2 className="h-5 w-5" />
            <span>Excluir</span>
          </button>
        </div>
      </div>

      {/* Status Badge */}
      <div className="flex items-center space-x-4">
        <span className={`px-4 py-2 rounded-full text-sm font-medium ${getStatusColor(vaga.status)}`}>
          {getStatusText(vaga.status)}
        </span>
      </div>

      {/* Informações Principais */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coluna Principal */}
        <div className="lg:col-span-2 space-y-6">
          {/* Requisitos Obrigatórios */}
          <div className="card">
            <div className="flex items-center mb-4">
              <FileText className="h-6 w-6 text-red-600 mr-3" />
              <h2 className="text-xl font-semibold text-gray-900">
                Requisitos Obrigatórios
              </h2>
            </div>
            <p className="text-gray-700 leading-relaxed">
              {vaga.requisitosObrigatorios}
            </p>
          </div>

          {/* Requisitos Desejáveis */}
          {vaga.requisitosDesejaveis && (
            <div className="card">
              <div className="flex items-center mb-4">
                <Award className="h-6 w-6 text-blue-600 mr-3" />
                <h2 className="text-xl font-semibold text-gray-900">
                  Requisitos Desejáveis
                </h2>
              </div>
              <p className="text-gray-700 leading-relaxed">
                {vaga.requisitosDesejaveis}
              </p>
            </div>
          )}

          {/* Benefícios */}
          {vaga.beneficios && (
            <div className="card">
              <div className="flex items-center mb-4">
                <Award className="h-6 w-6 text-green-600 mr-3" />
                <h2 className="text-xl font-semibold text-gray-900">
                  Benefícios
                </h2>
              </div>
              <p className="text-gray-700 leading-relaxed">
                {vaga.beneficios}
              </p>
            </div>
          )}
        </div>

        {/* Sidebar com Informações */}
        <div className="space-y-6">
          {/* Informações Básicas */}
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Informações da Vaga
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center text-gray-700">
                <DollarSign className="h-5 w-5 text-green-600 mr-3" />
                <div>
                  <p className="font-medium">Remuneração</p>
                  <p className="text-lg font-bold text-green-600">
                    R$ {vaga.remuneracaoMensal.toLocaleString('pt-BR')}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center text-gray-700">
                <MapPin className="h-5 w-5 text-blue-600 mr-3" />
                <div>
                  <p className="font-medium">Local</p>
                  <p>{vaga.localTrabalho}</p>
                </div>
              </div>
              
              {vaga.departamento && (
                <div className="flex items-center text-gray-700">
                  <Building className="h-5 w-5 text-purple-600 mr-3" />
                  <div>
                    <p className="font-medium">Departamento</p>
                    <p>{vaga.departamento}</p>
                  </div>
                </div>
              )}
              
              {vaga.tipoContrato && (
                <div className="flex items-center text-gray-700">
                  <Briefcase className="h-5 w-5 text-orange-600 mr-3" />
                  <div>
                    <p className="font-medium">Tipo de Contrato</p>
                    <p>{vaga.tipoContrato}</p>
                  </div>
                </div>
              )}
              
              {vaga.cargaHoraria && (
                <div className="flex items-center text-gray-700">
                  <Clock className="h-5 w-5 text-indigo-600 mr-3" />
                  <div>
                    <p className="font-medium">Carga Horária</p>
                    <p>{vaga.cargaHoraria}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Informações de Auditoria */}
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Informações do Sistema
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center text-gray-700">
                <Calendar className="h-5 w-5 text-gray-600 mr-3" />
                <div>
                  <p className="font-medium">Criada em</p>
                  <p>{new Date(vaga.criadoEm).toLocaleString('pt-BR')}</p>
                </div>
              </div>
              
              {vaga.atualizadoEm && vaga.atualizadoEm !== vaga.criadoEm && (
                <div className="flex items-center text-gray-700">
                  <Calendar className="h-5 w-5 text-gray-600 mr-3" />
                  <div>
                    <p className="font-medium">Última atualização</p>
                    <p>{new Date(vaga.atualizadoEm).toLocaleString('pt-BR')}</p>
                  </div>
                </div>
              )}
              
              {vaga.criadoPor && (
                <div className="flex items-center text-gray-700">
                  <User className="h-5 w-5 text-gray-600 mr-3" />
                  <div>
                    <p className="font-medium">Criada por</p>
                    <p>{vaga.criadoPor}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DetalhesVaga
