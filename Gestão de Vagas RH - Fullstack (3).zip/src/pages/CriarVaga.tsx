
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useVagas } from '../hooks/useVagas'
import {ArrowLeft, Save} from 'lucide-react'

const CriarVaga: React.FC = () => {
  const navigate = useNavigate()
  const { criarVaga } = useVagas()
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setLoading(true)

    const formData = new FormData(event.currentTarget)
    
    try {
      await criarVaga({
        descricaoCargo: formData.get('descricaoCargo') as string,
        requisitosObrigatorios: formData.get('requisitosObrigatorios') as string,
        requisitosDesejaveis: formData.get('requisitosDesejaveis') as string || undefined,
        remuneracaoMensal: Number(formData.get('remuneracaoMensal')),
        beneficios: formData.get('beneficios') as string || undefined,
        localTrabalho: formData.get('localTrabalho') as string,
        status: formData.get('status') as 'aberta' | 'preenchida' | 'cancelada',
        departamento: formData.get('departamento') as string || undefined,
        tipoContrato: formData.get('tipoContrato') as string || undefined,
        cargaHoraria: formData.get('cargaHoraria') as string || undefined,
        criadoPor: 'admin' // Em um sistema real, seria o usuário logado
      })
      
      navigate('/')
    } catch (error) {
      // Erro já tratado no hook
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <button
          onClick={() => navigate('/')}
          className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Nova Vaga</h1>
          <p className="text-gray-600 mt-1">
            Cadastre uma nova vaga de emprego
          </p>
        </div>
      </div>

      {/* Formulário */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            Informações Básicas
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descrição do Cargo *
              </label>
              <input
                type="text"
                name="descricaoCargo"
                required
                className="input-field"
                placeholder="Ex: Desenvolvedor Full Stack Sênior"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Remuneração Mensal (R$) *
              </label>
              <input
                type="number"
                name="remuneracaoMensal"
                min="0"
                step="0.01"
                required
                className="input-field"
                placeholder="5000.00"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Local de Trabalho *
              </label>
              <input
                type="text"
                name="localTrabalho"
                required
                className="input-field"
                placeholder="São Paulo - SP (Híbrido)"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status *
              </label>
              <select name="status" required className="input-field">
                <option value="aberta">Aberta</option>
                <option value="preenchida">Preenchida</option>
                <option value="cancelada">Cancelada</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Departamento
              </label>
              <input
                type="text"
                name="departamento"
                className="input-field"
                placeholder="Tecnologia"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tipo de Contrato
              </label>
              <select name="tipoContrato" className="input-field">
                <option value="">Selecione...</option>
                <option value="CLT">CLT</option>
                <option value="PJ">PJ</option>
                <option value="Estágio">Estágio</option>
                <option value="Temporário">Temporário</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Carga Horária
              </label>
              <input
                type="text"
                name="cargaHoraria"
                className="input-field"
                placeholder="40 horas semanais"
              />
            </div>
          </div>
        </div>

        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            Requisitos e Benefícios
          </h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Requisitos Obrigatórios *
              </label>
              <textarea
                name="requisitosObrigatorios"
                required
                rows={4}
                className="input-field"
                placeholder="Descreva os requisitos obrigatórios para a vaga..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Requisitos Desejáveis
              </label>
              <textarea
                name="requisitosDesejaveis"
                rows={3}
                className="input-field"
                placeholder="Descreva os requisitos desejáveis para a vaga..."
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Benefícios
              </label>
              <textarea
                name="beneficios"
                rows={3}
                className="input-field"
                placeholder="Descreva os benefícios oferecidos..."
              />
            </div>
          </div>
        </div>

        {/* Botões de Ação */}
        <div className="flex justify-end space-x-4">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="btn-secondary"
          >
            Cancelar
          </button>
          
          <button
            type="submit"
            disabled={loading}
            className="btn-primary flex items-center space-x-2"
          >
            <Save className="h-5 w-5" />
            <span>{loading ? 'Salvando...' : 'Salvar Vaga'}</span>
          </button>
        </div>
      </form>
    </div>
  )
}

export default CriarVaga
