
import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useVagas } from '../hooks/useVagas'
import {Eye, Edit, Trash2, Plus, Filter, MapPin, DollarSign, Calendar, Building, Users, AlertCircle} from 'lucide-react'

const ListaVagas: React.FC = () => {
  const { vagas, loading, buscarVagas, excluirVaga } = useVagas()
  const [filtroStatus, setFiltroStatus] = useState('todas')
  const [filtroDepartamento, setFiltroDepartamento] = useState('todos')

  const handleFiltroChange = (status: string, departamento: string) => {
    setFiltroStatus(status)
    setFiltroDepartamento(departamento)
    buscarVagas({ status, departamento })
  }

  const handleExcluir = async (id: string, descricao: string) => {
    if (window.confirm(`Tem certeza que deseja excluir a vaga "${descricao}"?`)) {
      await excluirVaga(id)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'aberta':
        return 'bg-green-100 text-green-800'
      case 'preenchida':
        return 'bg-blue-100 text-blue-800'
      case 'cancelada':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'aberta':
        return 'Aberta'
      case 'preenchida':
        return 'Preenchida'
      case 'cancelada':
        return 'Cancelada'
      default:
        return status
    }
  }

  const departamentosUnicos = [...new Set(vagas.map(v => v.departamento).filter(Boolean))]

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Vagas em Aberto</h1>
          <p className="text-gray-600 mt-1">
            Gerencie todas as vagas do departamento de RH
          </p>
        </div>
        
        <Link
          to="/criar"
          className="btn-primary flex items-center space-x-2"
        >
          <Plus className="h-5 w-5" />
          <span>Nova Vaga</span>
        </Link>
      </div>

      {/* Filtros */}
      <div className="card">
        <div className="flex items-center space-x-4">
          <Filter className="h-5 w-5 text-gray-500" />
          <div className="flex space-x-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                value={filtroStatus}
                onChange={(e) => handleFiltroChange(e.target.value, filtroDepartamento)}
                className="input-field w-40"
              >
                <option value="todas">Todas</option>
                <option value="aberta">Abertas</option>
                <option value="preenchida">Preenchidas</option>
                <option value="cancelada">Canceladas</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Departamento
              </label>
              <select
                value={filtroDepartamento}
                onChange={(e) => handleFiltroChange(filtroStatus, e.target.value)}
                className="input-field w-48"
              >
                <option value="todos">Todos</option>
                {departamentosUnicos.map(dep => (
                  <option key={dep} value={dep}>{dep}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total de Vagas</p>
              <p className="text-2xl font-semibold text-gray-900">{vagas.length}</p>
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <AlertCircle className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Abertas</p>
              <p className="text-2xl font-semibold text-gray-900">
                {vagas.filter(v => v.status === 'aberta').length}
              </p>
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Building className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Preenchidas</p>
              <p className="text-2xl font-semibold text-gray-900">
                {vagas.filter(v => v.status === 'preenchida').length}
              </p>
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center">
            <div className="p-2 bg-red-100 rounded-lg">
              <Trash2 className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Canceladas</p>
              <p className="text-2xl font-semibold text-gray-900">
                {vagas.filter(v => v.status === 'cancelada').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Lista de Vagas */}
      {vagas.length === 0 ? (
        <div className="card text-center py-12">
          <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhuma vaga encontrada
          </h3>
          <p className="text-gray-600 mb-6">
            Não há vagas cadastradas com os filtros selecionados.
          </p>
          <Link to="/criar" className="btn-primary">
            Criar primeira vaga
          </Link>
        </div>
      ) : (
        <div className="grid gap-6">
          {vagas.map((vaga) => (
            <div key={vaga._id} className="card">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-semibold text-gray-900">
                      {vaga.descricaoCargo}
                    </h3>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(vaga.status)}`}>
                      {getStatusText(vaga.status)}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                    <div className="flex items-center text-gray-600">
                      <DollarSign className="h-4 w-4 mr-2" />
                      <span>R$ {vaga.remuneracaoMensal.toLocaleString('pt-BR')}</span>
                    </div>
                    
                    <div className="flex items-center text-gray-600">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span>{vaga.localTrabalho}</span>
                    </div>
                    
                    {vaga.departamento && (
                      <div className="flex items-center text-gray-600">
                        <Building className="h-4 w-4 mr-2" />
                        <span>{vaga.departamento}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center text-gray-600">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>{new Date(vaga.criadoEm).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-4 line-clamp-2">
                    {vaga.requisitosObrigatorios}
                  </p>
                </div>
                
                <div className="flex space-x-2 ml-4">
                  <Link
                    to={`/detalhes/${vaga._id}`}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="Ver detalhes"
                  >
                    <Eye className="h-5 w-5" />
                  </Link>
                  
                  <Link
                    to={`/editar/${vaga._id}`}
                    className="p-2 text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors"
                    title="Editar vaga"
                  >
                    <Edit className="h-5 w-5" />
                  </Link>
                  
                  <button
                    onClick={() => handleExcluir(vaga._id, vaga.descricaoCargo)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Excluir vaga"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default ListaVagas
