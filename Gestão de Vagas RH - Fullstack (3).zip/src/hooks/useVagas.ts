
import { useState, useEffect } from 'react'
import { lumi } from '../lib/lumi'
import toast from 'react-hot-toast'

export interface Vaga {
  _id: string
  descricaoCargo: string
  requisitosObrigatorios: string
  requisitosDesejaveis?: string
  remuneracaoMensal: number
  beneficios?: string
  localTrabalho: string
  status: 'aberta' | 'preenchida' | 'cancelada'
  departamento?: string
  tipoContrato?: string
  cargaHoraria?: string
  criadoPor?: string
  criadoEm: string
  atualizadoEm?: string
}

export const useVagas = () => {
  const [vagas, setVagas] = useState<Vaga[]>([])
  const [loading, setLoading] = useState(false)

  const buscarVagas = async (filtros?: { status?: string; departamento?: string }) => {
    setLoading(true)
    try {
      const filter: any = {}
      if (filtros?.status && filtros.status !== 'todas') {
        filter.status = filtros.status
      }
      if (filtros?.departamento && filtros.departamento !== 'todos') {
        filter.departamento = filtros.departamento
      }

      const response = await lumi.entities.vagas.list({
        filter,
        sort: { criadoEm: -1 }
      })
      setVagas(response.list || [])
    } catch (error: any) {
      console.error('Erro ao buscar vagas:', error)
      toast.error('Erro ao carregar vagas')
    } finally {
      setLoading(false)
    }
  }

  const criarVaga = async (dadosVaga: Omit<Vaga, '_id' | 'criadoEm' | 'atualizadoEm'>) => {
    try {
      const novaVaga = await lumi.entities.vagas.create({
        ...dadosVaga,
        criadoEm: new Date().toISOString(),
        atualizadoEm: new Date().toISOString()
      })
      
      setVagas(prev => [novaVaga, ...prev])
      toast.success('Vaga criada com sucesso!')
      return novaVaga
    } catch (error: any) {
      console.error('Erro ao criar vaga:', error)
      toast.error('Erro ao criar vaga')
      throw error
    }
  }

  const atualizarVaga = async (id: string, atualizacoes: Partial<Vaga>) => {
    try {
      const vagaAtualizada = await lumi.entities.vagas.update(id, {
        ...atualizacoes,
        atualizadoEm: new Date().toISOString()
      })
      
      setVagas(prev => prev.map(v => v._id === id ? vagaAtualizada : v))
      toast.success('Vaga atualizada com sucesso!')
      return vagaAtualizada
    } catch (error: any) {
      console.error('Erro ao atualizar vaga:', error)
      toast.error('Erro ao atualizar vaga')
      throw error
    }
  }

  const excluirVaga = async (id: string) => {
    try {
      await lumi.entities.vagas.delete(id)
      setVagas(prev => prev.filter(v => v._id !== id))
      toast.success('Vaga excluída com sucesso!')
    } catch (error: any) {
      console.error('Erro ao excluir vaga:', error)
      toast.error('Erro ao excluir vaga')
      throw error
    }
  }

  const obterVaga = async (id: string): Promise<Vaga | null> => {
    try {
      const vaga = await lumi.entities.vagas.get(id)
      return vaga
    } catch (error: any) {
      console.error('Erro ao buscar vaga:', error)
      toast.error('Erro ao carregar vaga')
      return null
    }
  }

  useEffect(() => {
    buscarVagas()
  }, [])

  return {
    vagas,
    loading,
    buscarVagas,
    criarVaga,
    atualizarVaga,
    excluirVaga,
    obterVaga
  }
}
